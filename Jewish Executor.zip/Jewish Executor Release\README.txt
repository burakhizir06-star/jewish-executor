Jewish Executor

To use:
1. Extract this entire folder.
2. Open Roblox.
3. Run 'jewish executor.exe'.
4. Click Attach, then execute your scripts!

Ensure SyntaxAPI.dll is in the same folder as the executable!

Enjoy!
